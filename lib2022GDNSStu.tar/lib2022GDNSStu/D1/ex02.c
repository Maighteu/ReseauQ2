#include "stdio.h"

main()
{
 FILE *fp ;
 char Buffer[81] ;

 fp = fopen("ex01.c","r") ;
 while ( fgets(Buffer,sizeof Buffer,fp),!feof(fp) )
 {
  printf("%s",Buffer) ;
 }
 fclose(fp) ;
}

