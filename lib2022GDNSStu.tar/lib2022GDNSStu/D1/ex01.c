
#include <stdio.h>
#include <string.h>

main()
{
 char  B1[30] ,B2[30],B3[30],BB[30],BB2[30] ;
 int d1,d2,d3 ;

 char *Buffer = "primary    249.249.192.in-addr.arpa     db.192.249.249" ;
 char *Buffer2="249.192.in-addr.arpa" ;

 bzero(B1,sizeof B1 ) ; bzero(B1,sizeof B2 ) ; bzero(B1,sizeof B3 ) ;
 sscanf(Buffer,"%30s  %30s ",B1,B2) ;
 printf("T1 %s  %s \n",B1,B2) ;
 bzero(B1,sizeof B1 ) ; bzero(B1,sizeof B2 ) ; bzero(B1,sizeof B3 ) ;
 sscanf(Buffer,"%30s  %30s  %30s",B1,B2,B3) ;
 printf("T2 %s  %s  %s \n",B1,B2,B3) ;
 sscanf(B2,"%d.%d.%d.%30s",&d1,&d2,&d3,BB) ;
 printf(" %d %d %d %s\n",d1,d2,d3,BB) ;

 d1 = d2 = d3 = 0 ;
 sscanf(Buffer2,"%d.%d.%d.%30s",&d1,&d2,&d3,B3) ;
 printf(" %d %d %d %s\n",d1,d2,d3,BB) ;
 
 sscanf(Buffer2,"%d.%d.%30s",&d1,&d2,B3) ;
 printf(" %d %d %s\n",d1,d2,BB) ;
}


